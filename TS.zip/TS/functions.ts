let array=(num1:number,num2:number)=>num1+num2;

console.log(array(4,55));