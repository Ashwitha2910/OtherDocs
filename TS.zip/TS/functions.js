var array = function (num1, num2) { return num1 + num2; };
console.log(array(4, 55));
