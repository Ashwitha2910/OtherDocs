// console.log('Ashwitha vedi ahe');
// let arr:number[]=[2,4,5,6,]
// console.log(arr)
// arr.pop()
// console.log(arr)
    

type Employee={
    fname:string,
    lname:string
}

let emp:Employee={
    fname:"Ashwitha",
    lname:"K"
}

console.log(emp)