let a:any;
let b:unknown;

a=24;
b=22;
b="Ash";
console.log(typeof(b))