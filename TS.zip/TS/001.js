// console.log('Ashwitha vedi ahe');
// let arr:number[]=[2,4,5,6,]
// console.log(arr)
// arr.pop()
// console.log(arr)
var emp = {
    fname: "Ashwitha",
    lname: "K"
};
console.log(emp);
