--1.
CREATE PROCEDURE pr_convert (@val VARCHAR(20))
AS
BEGIN
	DECLARE @InStr VARCHAR(30);
	BEGIN TRY
		SET @InStr = CONVERT(int, @val);
		PRINT REPLICATE('Hello ', @InStr)
	END TRY
	BEGIN CATCH
		IF ERROR_NUMBER() = 245
			PRINT 'String cannot be converted to Integer.'
	END CATCH
END;
DROP Procedure pr_convert;
EXECUTE pr_convert @val= 'Ashwitha';
EXECUTE pr_convert @val = 10;


--2.
CREATE TABLE #temp
(
EmpID INT PRIMARY KEY,
EmpName VARCHAR(50),
Salary MONEY
)
DROP TABLE #temp

BEGIN TRY
    DECLARE @Salary INT;
	SET @Salary=-70
    IF @Salary<=0
        THROW 50001,'Salary cannot be 0 or negative',1
    ELSE IF @Salary>0 AND @Salary<10000
        THROW 50002,'Salary Less than 10000',1
	ELSE
		THROW 50003,'Salary Greater than 10000',1
END TRY
BEGIN CATCH
	PRINT ERROR_NUMBER();
	 PRINT ERROR_MESSAGE();
END CATCH



/*3.Create a temp table to represent employees.
Design a user defined exception to handle the salary input less than 10000.
*/

DECLARE @PID INT;
DECLARE @PName VARCHAR(50);
DECLARE @Color VARCHAR(10);
DECLARE @StdCost VARCHAR(10);
DECLARE cur_prod CURSOR FOR
SELECT TOP 10
ProductID,
Name,Color,
StandardCost
FROM
Production.Product
ORDER BY StandardCost DESC;
OPEN cur_prod;
FETCH NEXT FROM cur_prod INTO @PID,@PName,@Color,@StdCost;
WHILE @@FETCH_STATUS = 0                       
BEGIN
    PRINT '========================';
	PRINT CONCAT('Product ID: ' ,@PID);
    PRINT 'Product Name: ' + @PName;
	PRINT 'Color: ' + @Color;
    PRINT 'Standard Cost: ' + @StdCost;
    PRINT '========================';
    FETCH NEXT FROM cur_prod INTO @PID,@PName,@Color,@StdCost;
END;
CLOSE cur_prod;
DEALLOCATE cur_prod;

SELECT TOP 10 Name,Color,StandardCost FROM Production.Product
ORDER BY StandardCost DESC

------4
--Document your understanding and possible solutions to Deadlock concept
/*
Deadlocks occur when two processes want to access resources that are mutually being locked by each other.
This locked situation can continue forever if nobody stops it. Assume that two plumbers are making some
repair in the same bathroom, and one of them is using a plunger and require wrench at the same time in his repair.
The other one is using a wrench and required a plunger at the same time in his repair.
Otherwise, none of them can complete their work.
*/