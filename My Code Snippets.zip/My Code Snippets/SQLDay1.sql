CREATE SCHEMA Sales;
CREATE SCHEMA Production;
CREATE SCHEMA HumanResources;
CREATE SCHEMA Person;

CREATE TABLE Sales.Country
(
  CountryID INT PRIMARY KEY IDENTITY(1,1),
  CountryName VARCHAR(20) NOT NULL
);

CREATE TABLE Sales.Person
(
  PersonID INT PRIMARY KEY IDENTITY(101,1),
  Title VARCHAR(20),
  FirstName VARCHAR(15) NOT NULL,
  MiddleName VARCHAR(10),
  LastName VARCHAR(15) NOT NULL,
  Gender VARCHAR(1) CHECK(Gender IN('M','F','O','U')) NOT NULL,
  ModifiedDate DATE DEFAULT GETDATE()
);

CREATE TABLE HumanResources.Department
(
  DepartmentID INT PRIMARY KEY IDENTITY(201,1),
  DepartmentName VARCHAR NOT NULL
);

CREATE TABLE Production.ProductCategory
(
  ProductCategoryID INT PRIMARY KEY IDENTITY(301,1),
  ProductCategoryName VARCHAR(20) NOT NULL
);

CREATE TABLE Sales.Territory
(
   TerritoryID INT PRIMARY KEY IDENTITY(401,1),
   TerritoryName VARCHAR(20) NOT NULL,
   CountryID INT REFERENCES Sales.Country(CountryID) ON DELETE CASCADE
);

CREATE TABLE Sales.Customer
(
CustomerID INT PRIMARY KEY IDENTITY(501,1),
PersonID INT REFERENCES Sales.Person(PersonID) ON DELETE CASCADE,
TerritoryID INT REFERENCES Sales.Territory(TerritoryID) ON DELETE CASCADE,
CustomerGrade VARCHAR(2)
);

CREATE TABLE HumanResources.Employee
(
  EmployeeID INT PRIMARY KEY IDENTITY(601,1),
  Designation VARCHAR(15) NOT NULL,
  ManagerID VARCHAR(10) NOT NULL,
  DateOfJoining DATE CHECK(DateOfJoining < GETDATE()) NOT NULL,
  DepartmentID INT REFERENCES HumanResources.Department(DepartmentID) ON DELETE SET NULL,
  PersonID INT REFERENCES Sales.Person(PersonID) ON DELETE CASCADE
);

CREATE TABLE Sales.SalesOrderHeader
(
SalesOrderHeaderID INT PRIMARY KEY IDENTITY(701,1),
OrderDate DATE CHECK(OrderDate < GETDATE()) NOT NULL,
CustomerID INT REFERENCES Sales.Customer(CustomerID),
SalesPersonID INT REFERENCES HumanResources.Employee(EmployeeID) ON DELETE SET NULL
);

CREATE TABLE Production.ProductSubCategory
(
ProductSubCategoryID INT PRIMARY KEY IDENTITY(801,1),
ProductSubCategoryName VARCHAR(20) NOT NULL,
ProductCategoryID INT REFERENCES Production.ProductCategory(ProductCategoryID) ON DELETE SET NULL
);

CREATE TABLE Production.Product
(
ProductID INT PRIMARY KEY IDENTITY(901,1),
ProductName VARCHAR(20) NOT NULL,
ProductCost VARCHAR(10) NOT NULL,
QualityInStock VARCHAR(15) NOT NULL,
ProductSubCategoryID INT REFERENCES Production.ProductSubCategory(ProductSubCategoryID) ON DELETE SET NULL
);

CREATE TABLE Sales.SalesOrderDetails
(
SalesOrderDetailsID INT PRIMARY KEY IDENTITY(1001,1),
SalesOrderHeaderID INT REFERENCES Sales.SalesOrderHeader(SalesOrderHeaderID),
ProductID INT REFERENCES Production.Product(ProductID),
OrderQuantity INT DEFAULT '1' NOT NULL
);