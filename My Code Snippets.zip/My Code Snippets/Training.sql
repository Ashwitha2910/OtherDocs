---Get top 25% of costliest prods
SELECT * FROM
(
    SELECT
    ProductID,Name,Color,
    StandardCost,ProductSubcategoryID,
    NTILE(4)OVER(PARTITION BY ProductSubcategoryID Order By StandardCost Desc) AS [NT]
    FROM Production.Product
)AS t WHERE NT=1;

---Get top 25% of costliest prods
SELECT * FROM
(
    SELECT
    BusinessEntityID,HireDate,
    JobTitle,SickLeaveHours,
    NTILE(10)OVER(Order By SickLeaveHours Desc) AS [NT]
    FROM HumanResources.Employee
)AS t WHERE NT IN (1);

---JOINS
--INNER JOIN
SELECT A.BusinessEntityID,A.FirstName,A.LastName, B.JobTitle FROM Person.Person A JOIN HumanResources.Employee B 
ON A.BusinessEntityID=B.BusinessEntityID;

--OUTER JOIN
SELECT A.BusinessEntityID,A.FirstName,A.LastName, B.JobTitle FROM Person.Person A LEFT OUTER JOIN HumanResources.Employee B 
ON A.BusinessEntityID=B.BusinessEntityID;

--ALL THE PRODUCT NAMES WITH ALL THE SUBCATEGORY AWA PRODUCT CATEGORY
SELECT A.ProductID,A.Name AS Product, B.Name AS SubCategory, C.Name AS Category FROM Production.Product A LEFT OUTER JOIN Production.ProductSubcategory B ON A.ProductSubcategoryID=b.ProductSubcategoryID
LEFT OUTER JOIN Production.ProductCategory C ON B.ProductCategoryID=C.ProductCategoryID;

--ALL THE ORDERS INCLUDING ALL THE PRODUCTS IN THAT ORDER
SELECT A.SalesOrderID,A.OrderDate,A.CustomerID,A.SalesPersonID,A.TerritoryID,C.ProductID,C.Name AS ProductName FROM Sales.SalesOrderHeader A RIGHT OUTER JOIN Sales.SalesOrderDetail B ON A.SalesOrderID=B.SalesOrderID
JOIN Production.Product C ON B.ProductID=C.ProductID;

--Names of all male employee
SELECT FirstName, LastName FROM Person.Person WHERE BusinessEntityID IN
(
 SELECT BusinessEntityID FROM HumanResources.Employee WHERE Gender='M'
);

--All the products Only if there is a product named 'Blade'=> MULTI COLUMN
SELECT * FROM Production.Product WHERE EXISTS
(SELECT * FROM Production.Product WHERE Name='Chain');

--All the products costlier than Chain and Touring pedal products
SELECT * FROM Production.Product WHERE StandardCost
>ALL(SELECT StandardCost FROM Production.Product WHERE Name IN('Chain','Touring Pedal'));

--CORELATED
--All the products costing greater than avg cost in its sub category
SELECT * FROM Production.Product AS A
WHERE StandardCost>(SELECT AVG(StandardCost) FROM Production.Product WHERE ProductSubcategoryID=A.ProductSubcategoryID);


--Create synonym for production.product
CREATE SYNONYM PRD FOR Production.Product;

SELECT * FROM PRD;

--VIEWS
--Read only
CREATE VIEW v AS
SELECT A.BusinessEntityID,A.FirstName,A.LastName, B.JobTitle FROM Person.Person A LEFT OUTER JOIN HumanResources.Employee B 
ON A.BusinessEntityID=B.BusinessEntityID;

SELECT * FROM v;
INSERT INTO v (FirstName,LastName,JobTitle) VALUES('Ash','Sharma','Full Stack');

--SEQUENCE
CREATE SEQUENCE seq_cessna AS INT
START WITH 101
INCREMENT BY 1
MAXVALUE 1000
MINVALUE 1
CYCLE    /*NO CYCLE =>Default*/ 
CACHE 10 /*CACHE 10 => Next 10 sequence will be available and it will push the value*/

SELECT NEXT VALUE FOR seq_cessna

--create 2 tables customer and employee 2 columns each id and name then create a sqc and use it to insert id columns 
--of both tables
CREATE TABLE Customer
(
 CutID INT PRIMARY KEY,
 Name VARCHAR(20) NOT NULL
);

CREATE TABLE Employee
(
 EmpID INT PRIMARY KEY,
 EmpName VARCHAR(20) NOT NULL
);
CREATE SEQUENCE seq AS INT
START WITH 1
INCREMENT BY 1
MAXVALUE 1000
MINVALUE 1
NO CYCLE
CACHE 10

INSERT INTO Customer VALUES (NEXT VALUE FOR seq, 'ASHWITHA');

SELECT * FROM Customer;


INSERT INTO Employee VALUES (NEXT VALUE FOR seq, 'AKHIL');
SELECT * FROM Employee;
DROP SEQUENCE seq_cessna

--CASE
SELECT BusinessEntityID,PersonType,
CASE PersonType
  WHEN 'EM' THEN 'Employee'
  WHEN 'IN' THEN 'INDIAN'
  WHEN 'SP' THEN 'Special Person'
  ELSE 'Anonymous' 
END AS [Person Type], FirstName,LastName
FROM Person.Person

--ROLLUP
SELECT ProductSubcategoryID,Color,Sum(StandardCost) AS Total FROM Production.Product
GROUP BY CUBE(ProductSubcategoryID,Color);

/*SET operations
      UNION
      UNION ALL
      INTERSECT
      MINUS*/

--BLOCKS
--Anonymous Block:
DECLARE @UserName VARCHAR(20);
SET @UserName='Ashwitha';
PRINT @UserName + 'is a smart girl';

--Assigning table data to variables
DECLARE @ProdName VARCHAR(20);
DECLARE @ProdClr VARCHAR(20);
DECLARE @StdCost MONEY;
DECLARE @ProdID INT =722;
SELECT @ProdName=Name,@ProdClr=Color,@StdCost=StandardCost
  FROM Production.Product WHERE ProductID=@ProdID;
PRINT 'PRODUCT ID: '+ CONVERT(VARCHAR(5),@ProdID);
PRINT 'PRODUCT Color: '+@ProdClr;
PRINT CONCAT('PRODUCT COST: ',@StdCost);

--NAME AND DESIGNATION OF EMPLOYEE No 3
DECLARE @EmpFName VARCHAR(10);
DECLARE @EmpMName VARCHAR(10);
DECLARE @EmpLName VARCHAR(10);
DECLARE @EmpID INT=3;
DECLARE @Desig VARCHAR(20);
SELECT @EmpFName=A.FirstName,@EmpMName=A.MiddleName,@EmpLName=A.LastName,@Desig=B.JobTitle
FROM Person.Person A JOIN HumanResources.Employee B ON A.BusinessEntityID=@EmpID AND B.BusinessEntityID=@EmpID;
PRINT CONCAT('Employee Name:',@EmpFName,' ',@EmpMName,' ',@EmpLName);
PRINT 'Designation: '+@Desig;

--IF-ELSE
--Declare 5 vars to represent marks of 5 subs with 40 as pasing marks.
--Calculate total marks and %. display all the marks % and total additionally display the result as pass or fail.
DECLARE @Sub1 INT=45;
DECLARE @Sub2 INT=50;
DECLARE @Sub3 INT=50;
DECLARE @Sub4 INT=60;
DECLARE @Sub5 INT=50;
DECLARE @Sum INT =@Sub1+@Sub2+@Sub3+@Sub4+@Sub5;
DECLARE @Percent FLOAT= (@Sum/5)*100;
IF @Sub1>=40 AND @Sub2>=40 AND @Sub3>=40 AND @Sub4>=40 AND @Sub5>=40
  BEGIN
     PRINT 'RESULT: PASS';
	 PRINT 'Total:' +CONVERT(VARCHAR(5),@Sum);
	 PRINT 'Percentage:'+CONVERT(VARCHAR(5),@Percent);
  END
	ELSE
	BEGIN
	  PRINT 'RESULT: FAIL';
	  PRINT 'Total:' +CONVERT(VARCHAR(5),@Sum);
	  PRINT 'Percentage:'+CONVERT(VARCHAR(5),@Percent);
	END

-----------------------------------------------------------------------------------------------------------
--STORED PROCEDURES
/*Create a SP to insert data in the CessnaTraineeEmployee Table. Chck the below before insert
1.FirstName & LastName must not be null
2.Gender must only be either F or M
3. Batch no must either 1 or 2
4.Random code must be between 1 to 10
*/
CREATE TABLE CessnaTraineeEmployees
(
 TraineeID INT PRIMARY KEY,
 FirstName VARCHAR(20) NOT NULL,
 LastName VARCHAR(20) NOT NULL,
 Gender VARCHAR(1) CHECK(Gender IN('M','F')),
 BatchNo INT CHECK(BatchNo IN(1,2)),
 RandomCode INT CHECK(RandomCode BETWEEN 1 AND 10)
);

CREATE PROCEDURE new_emp_1
(
    @TraineeID INT,    @FirstName VARCHAR(50),    @LastName Varchar(50),
    @Gender VARCHAR(1),    @BatchNo INT,    @RandomCode INT
)AS
BEGIN
  IF(@FirstName IS NOT NULL) AND
    (@LastName IS NOT NULL) AND
	(@Gender IN('M','F')) AND
	(@BatchNo IN(1,2)) AND
	(@RandomCode BETWEEN 1 AND 10)
  BEGIN
       INSERT INTO CessnaTraineeEmployees VALUES
        (@TraineeID,@FirstName,@LastName,@Gender,@BatchNo,@RandomCode);
        PRINT 'Record Succesfully Inserted!'
	END;
	ELSE
	BEGIN
	  PRINT 'Invalid Info';
END;
END;

EXECUTE dbo.new_emp_1 1111,'Anil','Sharma','M',5,3

EXECUTE dbo.new_emp_1 1234,'Ashwitha','Prabhu','F',2,7

EXECUTE dbo.new_emp_1 7654,'Prajna','Gowda','F',2,8

SELECT * FROM CessnaTraineeEmployees

CREATE PROCEDURE new_procedure
(
 @BID INT ,
 @Name VARCHAR(50) OUTPUT,
 @Desig VARCHAR(20) OUTPUT
)AS
BEGIN
   PRINT' Finding Person'
   SELECT @Name=CONCAT(A.FirstName,' ',A.LastName),@Desig=B.JobTitle FROM Person.Person A JOIN HumanResources.Employee B 
   ON A.BusinessEntityID=B.BusinessEntityID;
   PRINT 'Found Person'
END;

DECLARE @NM VARCHAR(50), @JT VARCHAR(20)
EXEC dbo.new_procedure 5, @NM OUTPUT, @JT OUTPUT
PRINT @NM
PRINT @JT

--User Defined Functions
CREATE FUNCTION udf_add(@Num1 INT,@Num2 INT) RETURNS INT
AS
BEGIN
   DECLARE @Sum INT
   SET @Sum=@Num1+@Num2;
   RETURN @Sum;
END;

--Calling Function
PRINT dbo.udf_add(10,20);

--Create funtion whivh returns name, color and Product cost using product id,
CREATE FUNCTION dbo.prod_det(@PID INT) RETURNS VARCHAR(100)
AS
BEGIN
  DECLARE @DET VARCHAR(100)
  SELECT @DET=CONCAT('Product Name: ',Name,'-','Color: ',ISNULL(Color,'NULL'),'-','Cost: ',StandardCost)
  FROM Production.Product WHERE ProductID=@PID;
  RETURN @DET;
END;

PRINT dbo.prod_det(4);
DROP FUNCTION prod_det

---CHECK if number is Armstrong number
CREATE FUNCTION armstrong(@num1 INT) RETURNS VARCHAR(50)
AS
BEGIN
  DECLARE @N INT
  DECLARE @REM INT
  DECLARE @SUM INT=0;
  WHILE (@N!=0)

    SET @REM=@num1%10;
	SET @N=@num1/10;
    SET @SUM=@SUM+(@REM*@REM*@REM);
  IF(@SUM=@num1)
    
END;