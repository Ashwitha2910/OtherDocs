 ---ASSIGMENT DAY 6
 /*1.
 */
 

CREATE FUNCTION prime_num(@num1 int, @num2 int)
RETURNS @OUTPUT TABLE (
    Prime_Num INT
)
AS
BEGIN
    DECLARE @PRIME INT=0
    DECLARE @i INT = @num1;    
    WHILE @i<= @num2
    BEGIN
        DECLARE @J INT = @i-1
        SET @PRIME=1
        WHILE @J>1
        BEGIN
            IF @i % @J=0
            BEGIN
                SET @PRIME=0
            END
            SET @J=@J-1
        END
        IF @PRIME =1
        BEGIN
            INSERT @OUTPUT VALUES (@I)
        END
        SET @i=@i+1
    END
    RETURN
END

Select * FROM prime_num(2,10);

/*2.
*/
CREATE FUNCTION Category(@CatName VARCHAR(255))
RETURNS @OUTPUT TABLE (
    Pid INT NULL,
    PName VARCHAR(100),
    PCategoryName VARCHAR(100)
)
AS
BEGIN
    
    INSERT INTO @OUTPUT
    SELECT * FROM (
        SELECT PRD.ProductID AS Pid, PRD.Name AS PName, PRC.Name  AS PCategoryName FROM Production.Product PRD
        JOIN Production.ProductSubcategory PSC
        ON PRD.ProductSubcategoryID = PSC.ProductSubcategoryID
        JOIN Production.ProductCategory PRC
        ON PSC.ProductCategoryID = PRC.ProductCategoryID
    ) CategoryTable WHERE CategoryTable.PCategoryName = @CatName
    RETURN
END
SELECT * FROM Production.ProductCategory

SELECT * FROM dbo.Category('Bikes')

/*3.
*/

CREATE TABLE BankAccounts(
    AccountID INT IDENTITY PRIMARY KEY,
    CustomerName VARCHAR(100),
    AccountType VARCHAR (100),
    Customer_Balance INT CHECK (Customer_Balance > 0),
    Modified_Date DATE
);



CREATE TABLE BankTransactions(
    TransactionID INT IDENTITY,
    AccountID INT REFERENCES BankAccounts(AccountID) ON DELETE CASCADE,
    TransactionDate DATE,
    TransactionType VARCHAR(100),
    TransactionAmount FLOAT
    
);



INSERT INTO BankAccounts VALUES
('Ashwitha','Current Account',85000, '2022-09-29'),
('Akhil','Savings Account',50000, '2022-08-09'),  
('Prajna','Current Account',250000, '2022-09-12'),  
('Mahesh', 'Savings Account',47000, '2022-08-19'),  
('Shishir', 'Savings Account',46000, '2022-09-29')  

SELECT * FROM BankAccounts;

CREATE TRIGGER update_account
ON BankAccounts
AFTER UPDATE
AS
BEGIN
    DECLARE @AccountID INT, @OldBalance INT, @Customer_amount VARCHAR(100),
    @TransactionType VARCHAR(100), @TransactionAmount FLOAT  
    SELECT @AccountID = AccountID, @Customer_amount = Customer_Balance FROM inserted
    SELECT @OldBalance = Customer_Balance FROM deleted
    SET @TransactionAmount = @Customer_amount - @OldBalance
    IF @TransactionAmount > 0 SET @TransactionType ='Credit'
    ELSE SET @TransactionType = 'Debit'
    INSERT INTO BankTransactions VALUES (@AccountID,GETDATE(),
    @TransactionType,ABS(@TransactionAmount)) 
END;

DROP TRIGGER update_account


Update BankAccounts set Customer_Balance = 2000 where AccountID = 2
Update BankAccounts set Customer_Balance = 30000 where AccountID = 3
Update BankAccounts set Customer_Balance = 45000 where AccountID = 5


SELECT * FROM BankTransactions
SELECT * FROM BankAccounts 



