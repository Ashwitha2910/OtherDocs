--1. Write a query to determine the number of customers in the Sales.Customer table.
SELECT COUNT(CustomerID) AS [No. of Customers] FROM Sales.Customer;

--2. Write a query using the Production.Product table that displays the minimum, maximum, and average ListPrice.
SELECT MIN(ListPrice) AS [Minimum ListPrice],MAX(ListPrice) AS [Maximum ListPrice],
AVG(ListPrice)AS [Average ListPrice] FROM Production.Product;

--3.Write a query that shows the total number of items ordered for each product. Use the Sales.SalesOrderDetail 
--table to write the query.
SELECT ProductID,SUM(OrderQty) AS [No.Of Items] FROM Sales.SalesOrderDetail GROUP BY ProductID;

--4. Write a query using the Sales.SalesOrderDetail table that displays a count of the detail lines for each SalesOrderID.
SELECT SalesOrderID, COUNT(SalesOrderDetailID) AS [Detail Count] FROM Sales.SalesOrderDetail GROUP BY SalesOrderID;

--5. Write a query using the Production.Product table that lists a count of the products in each product line.
SELECT ProductLine,COUNT(ProductID) AS [No.Of Products] FROM Production.Product GROUP BY ProductLine;


--6. Write a query that displays the count of orders placed by year for each customer using the Sales.SalesOrderHeader table.
SELECT SalesOrderID,YEAR(OrderDate)AS [Ordered Year], COUNT(OrderDate) AS[Count] FROM Sales.SalesOrderHeader
GROUP BY SalesOrderID, OrderDate;


--7. Write a query that creates a sum of the LineTotal in the Sales.SalesOrderDetail table grouped by the SalesOrderID.
--Include only those rows where the sum exceeds 1,000.
SELECT * FROM (SELECT SalesOrderID,SUM(LineTotal) AS Total FROM Sales.SalesOrderDetail 
GROUP BY SalesOrderID)t WHERE Total>1000;


--8. Write a query that groups the products by ProductModelID along with a count. 
--Display the rows that have a count that equals 1.
SELECT * FROM 
(SELECT ProductModelID,COUNT(ProductID) AS [ProductModel Count] FROM Production.Product GROUP BY ProductModelID)t
WHERE [ProductModel Count]=1;


--9. Write a query using the Sales.SalesOrderHeader, Sales.SalesOrderDetail, and Production.
--Product tables to display the total sum of products by ProductID and OrderDate.
SELECT��A.ProductID,C.OrderDate, SUM(LineTotal)OVER(Partition BY A.ProductId ORDER BY OrderDate)AS [Total Line]
FROM Production.Product A JOIN Sales.SalesOrderDetail B ON A.ProductID=B.ProductID
JOIN Sales.SalesOrderHeader C ON C.SalesOrderID=B.SalesOrderID

SELECT * FROM Sales.SalesOrderHeader
--10.Display the 3rd joined employee.
SELECT * FROM(SELECT BusinessEntityID,JobTitle,Gender,HireDate,ROW_NUMBER()OVER(ORDER BY YEAR(HireDate),MONTH(HireDate),DAY(HireDate)) AS [RNK] 
FROM HumanResources.Employee)t WHERE RNK=3;

--11.Display the customer who has placed 2nd highest orders
SELECT * FROM (
SELECT *,DENSE_RANK()OVER(ORDER BY Total DESC) AS [RNK] FROM 
(
SELECT DISTINCT B.CustomerID,D.FirstName,D.LastName,
SUM(A.LineTotal)OVER(Order by B.CustomerID) AS [Total] FROM Sales.SalesOrderDetail A
JOIN Sales.SalesOrderHeader C ON C.SalesOrderID=A.SalesOrderID JOIN Sales.Customer B ON B.CustomerID=C.CustomerID
JOIN Person.Person D ON D.BusinessEntityID=B.PersonID
)a
)b WHERE b.RNK=2;


--12. Display top 25% of costliest products in every subcategory
SELECT * FROM
(
    SELECT
    ProductID,Name,Color,
    StandardCost,ProductSubcategoryID,
    NTILE(4)OVER(PARTITION BY ProductSubCategoryID Order By StandardCost Desc) AS [NT]
    FROM Production.Product
)AS t WHERE NT=1;

--13.Create a sequence to be used in two different temporary tables
CREATE TABLE CSTMR
(
 CustID INT PRIMARY KEY,
 CustName VARCHAR(10)
);
CREATE TABLE SalesPeron
(
 SalesPersonID INT PRIMARY KEY,
 Name VARCHAR(10)
);
CREATE SEQUENCE sqnc
START WITH 1
INCREMENT BY 1
MAXVALUE 1000
MINVALUE 1
NO CYCLE
CACHE 10

INSERT INTO CSTMR VALUES(NEXT VALUE FOR sqnc,'Divya'),(NEXT VALUE FOR sqnc,'Karan');
INSERT INTO SalesPeron VALUES(NEXT VALUE FOR sqnc,'Mahesh'),(NEXT VALUE FOR sqnc,'Suraj');
INSERT INTO CSTMR VALUES(NEXT VALUE FOR sqnc,'Akash'),(NEXT VALUE FOR sqnc,'Zoya');
INSERT INTO SalesPeron VALUES(NEXT VALUE FOR sqnc,'Riya'),(NEXT VALUE FOR sqnc,'Varun');
SELECT * FROM CSTMR;
SELECT * FROM SalesPeron;
