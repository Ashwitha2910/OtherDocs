--1.The HumanResources.Employee table does not contain the employee names. Join that table to the Person.Person 
--table on the BusinessEntityID column. Display the job title, birth date,first name, and last name.
SELECT A.BusinessEntityID,A.FirstName,A.LastName,B.JobTitle,B.BirthDate FROM Person.Person A INNER JOIN HumanResources.Employee B 
ON A.BusinessEntityID=B.BusinessEntityID;


--2.The customer names also appear in the Person.Person table. Join the Sales.Customer table to the Person.Person table.
--The BusinessEntityID column in the Person.Person table matches the PersonID column in the Sales.Customer table.
--Display the CustomerID, StoreID, and TerritoryID columns along with the name columns.
SELECT B.CustomerID,A.FirstName,A.LastName,B.StoreID,B.TerritoryID FROM Person.Person A 
JOIN Sales.Customer B ON A.BusinessEntityID=B.PersonID;


--3.Write a query that joins the Sales.SalesOrderHeader table to the Sales. SalesPerson table.
--Join the BusinessEntityID column from the Sales.SalesPerson table to the SalesPersonID column in the Sales.SalesOrderHeader table.
--Display the SalesOrderID along with the SalesQuota and Bonus.
SELECT B.SalesOrderID,A.SalesQuota,A.Bonus FROM Sales.SalesPerson A JOIN Sales.SalesOrderHeader B
ON A.BusinessEntityID=B.SalesPersonID;

--4.The catalog description for each product is stored in the Production.ProductModel table. 
--Display the columns that describe the product from the Production.Product table, such as the color and size along 
--with the catalog description for each product.
SELECT A.Name,A.Color,A.Size,B.CatalogDescription FROM Production.Product A JOIN Production.ProductModel B 
ON A.ProductModelID=B.ProductModelID;

--5.Write a query that displays the names of the customers along with the product names that they have purchased.
--Hint: Five tables will be required to write this query!
SELECT E.FirstName,E.LastName,A.Name AS [Product Name],A.ListPrice
FROM Production.Product A
LEFT OUTER JOIN Sales.SalesOrderDetail B ON A.ProductID=B.ProductID
LEFT OUTER JOIN Sales.SalesOrderHeader C ON C.SalesOrderID=B.SalesOrderID
LEFT OUTER JOIN Sales.Customer D ON D.CustomerID=C.CustomerID
LEFT OUTER JOIN Person.Person E ON E.BusinessEntityID=D.PersonID;


--6.Write a query that displays all the products along with the SalesOrderID even if an order has never been placed
--for that product. Join to the Sales.SalesOrderDetail table using the ProductID column.
SELECT A.ProductID,A.Name,B.SalesOrderID FROM Production.Product A LEFT OUTER JOIN Sales.SalesOrderDetail B
ON A.ProductID=B.ProductID;

/*7.The Sales.SalesOrderHeader table contains foreign keys to the Sales.CurrencyRate and Purchasing.ShipMethod tables.
Write a query joining all three tables, making sure it contains all rows from Sales.SalesOrderHeader. 
Include the CurrencyRateID, AverageRate, SalesOrderID, and ShipBase columns.*/
SELECT A.SalesOrderID,B.CurrencyRateID,B.AverageRate,C.ShipBase FROM Sales.SalesOrderHeader A
LEFT OUTER JOIN Sales.CurrencyRate B ON A.CurrencyRateID=B.CurrencyRateID
LEFT OUTER JOIN Purchasing.ShipMethod C ON A.ShipMethodID=C.ShipMethodID

/*8.Get all the order details to gererate a report that displays, OrderID, OrderNumber, OrderDate, Shipping Date and 
the product names,subcategory and category which are the part of that order and include the name of customer who has
placed the order as well as the name of territory and country from where order has been placed 
[Hint: Identify the correct set of related tables]*/
SELECT A.SalesOrderID,I.FirstName,I.LastName,A.SalesOrderNumber,A.OrderDate,A.ShipDate,C.Name AS [Product],D.Name AS[SubCategory],E.Name AS
[Category],G.Name AS [Territory],H.Name AS [Country]
FROM Sales.SalesOrderHeader A 
RIGHT OUTER JOIN Sales.SalesOrderDetail B ON  A.SalesOrderID=B.SalesOrderID
LEFT OUTER JOIN Production.Product C ON B.ProductID=C.ProductID
LEFT OUTER JOIN Production.ProductSubcategory D ON C.ProductSubcategoryID=D.ProductSubcategoryID
LEFT OUTER JOIN Production.ProductCategory E ON D.ProductCategoryID=E.ProductCategoryID
LEFT OUTER JOIN Sales.Customer F ON A.CustomerID=F.CustomerID
LEFT OUTER JOIN Person.Person I ON F.CustomerID=I.BusinessEntityID
LEFT OUTER JOIN Sales.SalesTerritory G ON F.TerritoryID=G.TerritoryID
LEFT OUTER JOIN Person.CountryRegion H ON G.CountryRegionCode=H.CountryRegionCode

/*9.Get the Youngest Employee*/
SELECT BusinessEntityID FROM
(SELECT BusinessEntityID, DENSE_RANK()OVER(ORDER BY BirthDate DESC ) AS [RNK] FROM HumanResources.Employee)T
WHERE RNK=1;

/*10.Create a temp. table and copy the data form Production.Product table (only red colored products) in the temp.
table [Hint: use subquery]*/
CREATE TABLE RedProducts
(
 RedID INT,
 ProdName VARCHAR(50),
 Color VARCHAR(20),
 Cost VARCHAR(10),
 SubCategory INT
);

INSERT INTO RedProducts
SELECT ProductID, Name,Color,StandardCost,ProductSubcategoryID FROM Production.Product WHERE Color='Red';

SELECT * FROM RedProducts

